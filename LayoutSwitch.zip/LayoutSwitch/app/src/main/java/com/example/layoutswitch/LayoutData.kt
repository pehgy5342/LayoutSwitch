package com.example.layoutswitch

class LayoutData {
}