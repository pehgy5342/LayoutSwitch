package com.example.layoutswitch

class LayoutAdapter {
}